﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Com.Sogeti.Tests.SeleniumTest.Test_Data
{
    public class TestData
    {
        //Test Case 1         
        public static string firstName = "Rahul";
        public static string lastName = "Singhvi";
        public static string weekDay = "Thursday";
        public static string number = "3";

    }
}

